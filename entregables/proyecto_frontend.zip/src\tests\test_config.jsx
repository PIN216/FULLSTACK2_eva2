const crearStorage = () => {
  let store = {};
  return {
    getItem: (k) => (k in store ? store[k] : null),
    setItem: (k, v) => { store[k] = String(v); },
    removeItem: (k) => { delete store[k]; },
    clear: () => { store = {}; },
    key: (i) => Object.keys(store)[i] ?? null,
    get length() { return Object.keys(store).length; }
  };
};

Object.defineProperty(globalThis, 'localStorage', {
  value: crearStorage(),
  configurable: true,
  writable: true
});
Object.defineProperty(window, 'localStorage', {
  value: globalThis.localStorage,
  configurable: true,
  writable: true
});